


const scriptsInEvents = {

	async ["Gamemonitize-Js_Event1_Act1"](runtime, localVars)
	{
		if (typeof sdk !== 'undefined' && sdk.showBanner !== 'undefined') {
			sdk.showBanner();
		}
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

